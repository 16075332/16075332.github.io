export interface Iproduct{   
    ProductId: number;           
    Price: number;
    Image: string;
}