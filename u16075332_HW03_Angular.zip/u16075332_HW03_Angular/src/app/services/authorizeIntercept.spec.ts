import { Authorization } from "./authorizeIntercept";

describe('Authorization', () => {
  it('should create an instance', () => {
    expect(new Authorization()).toBeTruthy();
  });
});
